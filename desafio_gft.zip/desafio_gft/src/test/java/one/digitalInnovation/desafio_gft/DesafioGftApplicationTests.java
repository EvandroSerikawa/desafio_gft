package one.digitalInnovation.desafio_gft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesafioGftApplicationTests {

	@Test
	void contextLoads() {
	}

}
